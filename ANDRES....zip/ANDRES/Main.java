// vamos a crear un programa que Implemente una jerarquía de clases que representen figuras geométricas. 
package trabajo;
//by jn 

// Esta clase tiene el método main que ejecuta el programa
public class Main {
    public static void main(String[] args) {
        
               // Creamos los objetos de las figuras (las clases hijas)
        FiguraGeometrica circulo = new Circulo("Circulo", 5.0);
        FiguraGeometrica rectangulo = new Rectangulo("Rectangulo", 8.0, 4.0);
        FiguraGeometrica triangulo = new Triangulo("Triangulo", 6.0, 3.0);

        // Mostramos la información de cada figura
        circulo.mostrarInformacion();
        System.out.println("");
        rectangulo.mostrarInformacion();
        System.out.println("");
        triangulo.mostrarInformacion();

    }
}

