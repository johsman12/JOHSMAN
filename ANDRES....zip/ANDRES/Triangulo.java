// vamos a crear un programa que Implemente una jerarquía de clases que representen figuras geométricas. 
package trabajo;

//by jn


// Clase que representa un triángulo
public class Triangulo extends FiguraGeometrica {

    // Atributos específicos del triángulo
    private double base;
    private double altura;

    // Constructor: inicializa los valores
    public Triangulo(String nombre, double base, double altura) {
        super(nombre); // Llama al constructor del padre
        this.base = base;
        this.altura = altura;
    }

    // Implementación del método abstracto
    
    public double calcularArea() {
        // Fórmula del área del triángulo: (base * altura) / 2
        return (base * altura) / 2;
    }
}

