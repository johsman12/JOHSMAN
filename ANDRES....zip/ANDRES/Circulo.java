// vamos a crear un programa que Implemente una jerarquía de clases que representen figuras geométricas. 
package trabajo;

// by jn 

// Esta clase hereda de FiguraGeometrica
// que Representa una figura tipo círculo
public class Circulo extends FiguraGeometrica {
   // Atributo propio del círculo
    private double radio;

    // Constructor: inicializa el nombre y el radio
    public Circulo(String nombre, double radio) {
        super(nombre); // Llamamos al constructor del padre (FiguraGeometrica)
        this.radio = radio; // Inicializa el radio
    }

    // Implementamos el método abstracto calcularArea()
    
    public double calcularArea() {
        // Fórmula del área del círculo: π * radio²
        return Math.PI * Math.pow(radio, 2);
    }
}

