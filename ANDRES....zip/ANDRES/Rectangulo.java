// vamos a crear un programa que Implemente una jerarquía de clases que representen figuras geométricas. 
package trabajo;

//by jn

// Clase que representa un rectángulo
public class Rectangulo extends FiguraGeometrica {

    // Atributos propios del rectángulo
    private double base;
    private double altura;

    // Constructor: inicializa los valores
    public Rectangulo(String nombre, double base, double altura) {
        super(nombre); // Llama al constructor de FiguraGeometrica
        this.base = base;
        this.altura = altura;
    }

    // Implementación del método abstracto
    
    public double calcularArea() {
        // Fórmula: base * altura
        return base * altura;
    }
}

