// vamos a crear un programa que Implemente una jerarquía de clases que representen figuras geométricas. 

package trabajo;

//by jn

 //Esta es una clase abstracta
public abstract class FiguraGeometrica {
    // Atributo común para todas las figuras
    protected String nombre;

    // Constructor: sirve para darle un nombre a cada figura
    public FiguraGeometrica(String nombre) {
        this.nombre = nombre;
    }

    // Método abstracto: cada figura lo debe implementar a su manera
    public abstract double calcularArea();

    // Método normal: muestra información general de la figura
    public void mostrarInformacion() {
        System.out.println("Figura: " + nombre);
        System.out.println("area: " + calcularArea());
    }
}

